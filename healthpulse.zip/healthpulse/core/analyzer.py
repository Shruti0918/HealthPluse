"""
Lightweight rule-based symptom analysis engine.

This mimics an "AI-driven" triage assistant: it scores free-text symptom
descriptions against a small knowledge base of condition patterns and
returns a plain-language summary plus an urgency level. It is intentionally
simple (no external API keys required) so the project runs anywhere, but
the same interface (`analyze_symptoms`) could be swapped out for a call to
a real LLM API without changing any other part of the app.
"""

import re

# Each pattern: (condition name, keywords, urgency, advice)
KNOWLEDGE_BASE = [
    ("Common Cold", ["runny nose", "sneezing", "sore throat", "cough", "congestion"],
     "low", "Rest, stay hydrated, and monitor symptoms. Usually resolves in 7-10 days."),
    ("Migraine", ["headache", "light sensitivity", "nausea", "throbbing", "aura"],
     "medium", "Rest in a dark, quiet room. Consider over-the-counter pain relief. See a doctor if frequent."),
    ("Possible Flu", ["fever", "body ache", "chills", "fatigue", "headache"],
     "medium", "Rest and fluids are key. Seek care if fever exceeds 103°F (39.4°C) or lasts more than 3 days."),
    ("Gastrointestinal Upset", ["stomach pain", "nausea", "vomiting", "diarrhea", "cramps"],
     "medium", "Stay hydrated with small sips of water. Bland diet recommended. See a doctor if symptoms persist beyond 48 hours."),
    ("Possible Allergic Reaction", ["rash", "itching", "hives", "swelling", "watery eyes"],
     "medium", "Avoid the suspected allergen. Antihistamines may help. Seek urgent care if breathing is affected."),
    ("Cardiac Emergency", ["chest pain", "shortness of breath", "arm pain", "tightness in chest", "crushing pain"],
     "high", "These symptoms can indicate a medical emergency. Seek immediate medical attention or call emergency services."),
    ("Severe Emergency", ["difficulty breathing", "unconscious", "severe bleeding", "stroke", "slurred speech"],
     "high", "This may be a medical emergency. Call emergency services immediately."),
]

URGENCY_RANK = {"low": 0, "medium": 1, "high": 2}


def analyze_symptoms(text: str):
    """
    Score the input text against the knowledge base.
    Returns a dict with: matches (list of condition names), summary, urgency.
    """
    text_lower = text.lower()
    matches = []
    highest_urgency = "low"

    for condition, keywords, urgency, advice in KNOWLEDGE_BASE:
        hits = sum(1 for kw in keywords if kw in text_lower)
        if hits > 0:
            score = hits / len(keywords)
            matches.append({
                "condition": condition,
                "score": round(score, 2),
                "urgency": urgency,
                "advice": advice,
            })
            if URGENCY_RANK[urgency] > URGENCY_RANK[highest_urgency]:
                highest_urgency = urgency

    matches.sort(key=lambda m: m["score"], reverse=True)

    if not matches:
        summary = (
            "We couldn't confidently match your symptoms to a known pattern. "
            "This is not a diagnosis — please consult a healthcare professional "
            "if symptoms persist or worsen."
        )
    else:
        top = matches[0]
        summary = (
            f"Your symptoms most closely resemble '{top['condition']}'. {top['advice']}"
        )

    return {
        "matches": matches[:3],
        "summary": summary,
        "urgency": highest_urgency,
        "disclaimer": "This tool provides general guidance only and is not a substitute for professional medical advice.",
    }
