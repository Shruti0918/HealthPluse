from django.db import models
from django.utils import timezone


class Medication(models.Model):
    """A medication the user needs to take, with a reminder time."""
    name = models.CharField(max_length=120)
    dosage = models.CharField(max_length=80, blank=True)
    reminder_time = models.TimeField(help_text="Time of day to be reminded")
    notes = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_notified_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} @ {self.reminder_time.strftime('%H:%M')}"


class SymptomCheck(models.Model):
    """A record of a symptom analysis request, so users can see their history."""
    symptoms_text = models.TextField()
    result_summary = models.TextField()
    urgency = models.CharField(max_length=20, default="low")
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Check on {self.created_at:%Y-%m-%d %H:%M} ({self.urgency})"
