import json
from datetime import date

from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from .analyzer import analyze_symptoms
from .models import Medication, SymptomCheck


def index(request):
    """Main single-page dashboard: symptom checker + medication list."""
    medications = Medication.objects.order_by("reminder_time")
    recent_checks = SymptomCheck.objects.order_by("-created_at")[:5]
    return render(request, "core/index.html", {
        "medications": medications,
        "recent_checks": recent_checks,
    })


@csrf_exempt
@require_http_methods(["POST"])
def api_check_symptoms(request):
    """POST { symptoms: str } -> JSON analysis result. Also logs the check."""
    try:
        payload = json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON body"}, status=400)

    symptoms_text = (payload.get("symptoms") or "").strip()
    if not symptoms_text:
        return JsonResponse({"error": "Please describe your symptoms."}, status=400)

    result = analyze_symptoms(symptoms_text)

    SymptomCheck.objects.create(
        symptoms_text=symptoms_text,
        result_summary=result["summary"],
        urgency=result["urgency"],
    )

    return JsonResponse(result)


@csrf_exempt
@require_http_methods(["POST"])
def api_add_medication(request):
    """POST { name, dosage, reminder_time (HH:MM), notes } -> create a Medication."""
    try:
        payload = json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON body"}, status=400)

    name = (payload.get("name") or "").strip()
    reminder_time = (payload.get("reminder_time") or "").strip()
    if not name or not reminder_time:
        return JsonResponse({"error": "name and reminder_time are required"}, status=400)

    med = Medication.objects.create(
        name=name,
        dosage=(payload.get("dosage") or "").strip(),
        reminder_time=reminder_time,
        notes=(payload.get("notes") or "").strip(),
    )
    med.refresh_from_db()
    return JsonResponse({
        "id": med.id,
        "name": med.name,
        "dosage": med.dosage,
        "reminder_time": med.reminder_time.strftime("%H:%M"),
        "notes": med.notes,
    })


@require_http_methods(["GET"])
def api_due_reminders(request):
    """
    GET -> list of medications whose reminder_time has passed for today
    and haven't been notified yet today. The front-end polls this
    endpoint asynchronously (via fetch + setInterval) to trigger
    browser notifications without a page reload.
    """
    now = timezone.localtime()
    today = date.today()
    due = []
    for med in Medication.objects.all():
        already_notified_today = med.last_notified_date == today
        if med.reminder_time <= now.time() and not already_notified_today:
            due.append(med)
            med.last_notified_date = today
            med.save(update_fields=["last_notified_date"])

    return JsonResponse({
        "due": [
            {"id": m.id, "name": m.name, "dosage": m.dosage, "notes": m.notes}
            for m in due
        ]
    })
