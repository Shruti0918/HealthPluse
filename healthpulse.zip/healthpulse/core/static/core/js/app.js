/**
 * HealthPulse front-end logic.
 * Handles the symptom checker form and asynchronous medication reminders.
 * "Asynchronous" here means the page polls the backend in the background
 * (via fetch + setInterval) and raises browser notifications without any
 * page reload — no separate task queue needed for a project this size.
 */

function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : null;
}

// ---- Symptom Checker ----
const checkBtn = document.getElementById('checkBtn');
const symptomsInput = document.getElementById('symptomsInput');
const resultBox = document.getElementById('resultBox');
const urgencyBadge = document.getElementById('urgencyBadge');
const resultSummary = document.getElementById('resultSummary');
const resultMatches = document.getElementById('resultMatches');

checkBtn.addEventListener('click', async () => {
    const text = symptomsInput.value.trim();
    if (!text) return;

    checkBtn.disabled = true;
    checkBtn.textContent = 'Analyzing...';

    try {
        const res = await fetch('/api/check-symptoms/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ symptoms: text }),
        });
        const data = await res.json();

        if (!res.ok) {
            alert(data.error || 'Something went wrong.');
            return;
        }

        urgencyBadge.textContent = data.urgency;
        urgencyBadge.className = `badge badge-${data.urgency}`;
        resultSummary.textContent = data.summary;

        resultMatches.innerHTML = '';
        data.matches.forEach((m) => {
            const li = document.createElement('li');
            li.textContent = `${m.condition} (confidence: ${Math.round(m.score * 100)}%)`;
            resultMatches.appendChild(li);
        });

        resultBox.classList.remove('hidden');
    } catch (err) {
        alert('Network error — is the server running?');
    } finally {
        checkBtn.disabled = false;
        checkBtn.textContent = 'Analyze Symptoms';
    }
});

// ---- Medication Reminders ----
const medForm = document.getElementById('medForm');
const medList = document.getElementById('medList');

medForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('medName').value.trim();
    const dosage = document.getElementById('medDosage').value.trim();
    const time = document.getElementById('medTime').value;
    const notes = document.getElementById('medNotes').value.trim();

    if (!name || !time) return;

    const res = await fetch('/api/medications/add/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, dosage, reminder_time: time, notes }),
    });

    if (!res.ok) {
        alert('Could not add medication.');
        return;
    }

    const med = await res.json();

    if (medList.querySelector('.muted')) medList.innerHTML = '';
    const li = document.createElement('li');
    li.innerHTML = `<strong>${med.name}</strong> ${med.dosage ? `(${med.dosage})` : ''} — ${med.reminder_time}` +
        (med.notes ? ` <span class="muted">· ${med.notes}</span>` : '');
    medList.appendChild(li);

    medForm.reset();
});

// ---- Async reminder polling ----
const toast = document.getElementById('notificationToast');

function showToast(message) {
    toast.textContent = message;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 6000);
}

async function pollReminders() {
    try {
        const res = await fetch('/api/reminders/due/');
        const data = await res.json();
        (data.due || []).forEach((med) => {
            const message = `Time to take ${med.name}${med.dosage ? ' (' + med.dosage + ')' : ''}`;
            if (window.Notification && Notification.permission === 'granted') {
                new Notification('HealthPulse Reminder', { body: message });
            } else {
                showToast(message);
            }
        });
    } catch (err) {
        // Silently ignore network hiccups during polling
    }
}

if (window.Notification && Notification.permission !== 'granted' && Notification.permission !== 'denied') {
    Notification.requestPermission();
}

// Poll every 30 seconds for due reminders (adjust as needed)
setInterval(pollReminders, 30000);
pollReminders();
