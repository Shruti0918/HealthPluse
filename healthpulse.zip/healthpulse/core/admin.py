from django.contrib import admin
from .models import Medication, SymptomCheck

admin.site.register(Medication)
admin.site.register(SymptomCheck)
