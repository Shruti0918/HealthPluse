from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("api/check-symptoms/", views.api_check_symptoms, name="api_check_symptoms"),
    path("api/medications/add/", views.api_add_medication, name="api_add_medication"),
    path("api/reminders/due/", views.api_due_reminders, name="api_due_reminders"),
]
