# HealthPulse — AI-Driven Healthcare Companion

A full-stack web app built with **Python (Django)** and **JavaScript**, combining
AI-driven symptom analysis with asynchronous medication reminders through a
responsive web interface. Built and tested on **Ubuntu (Linux)**.

## Features

- **Symptom Checker**: Describe symptoms in plain language and get a
  triage-style summary with urgency level (low / medium / high) and
  general guidance. Powered by a lightweight rule-based analysis engine
  (`core/analyzer.py`) that can be swapped for a real LLM API call without
  changing the rest of the app.
- **Medication Reminders**: Add medications with a dosage and time. The
  front-end polls the backend asynchronously (`fetch` + `setInterval`) and
  raises a browser notification (or in-page toast) when a dose is due —
  no page reload required.
- **Responsive UI**: Single-page dashboard built with vanilla HTML/CSS/JS,
  works on desktop and mobile.

## Tech Stack

| Layer      | Technology                     |
|------------|---------------------------------|
| Backend    | Python, Django                  |
| Frontend   | HTML5, CSS3, JavaScript (vanilla, fetch API) |
| Database   | SQLite (default; swappable)     |
| Deployment | Tested on Ubuntu (Linux)        |

## Getting Started

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/healthpulse.git
cd healthpulse

# 2. Create a virtual environment
python3 -m venv venv
source venv/bin/activate    # on Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run migrations
python manage.py migrate

# 5. Start the dev server
python manage.py runserver

# 6. Open http://127.0.0.1:8000/ in your browser
```

## Project Structure

```
healthpulse/
├── healthpulse/        # Django project settings & URL routing
├── core/                # Main app
│   ├── analyzer.py      # Symptom analysis engine
│   ├── models.py        # Medication & SymptomCheck models
│   ├── views.py         # Views + JSON API endpoints
│   ├── urls.py
│   ├── templates/core/  # index.html (dashboard)
│   └── static/core/     # CSS + JS
├── manage.py
└── requirements.txt
```

## API Endpoints

| Method | Endpoint                     | Description                          |
|--------|-------------------------------|---------------------------------------|
| POST   | `/api/check-symptoms/`        | Analyze free-text symptoms            |
| POST   | `/api/medications/add/`       | Add a medication reminder             |
| GET    | `/api/reminders/due/`         | Poll for reminders due right now      |

## Disclaimer

This project is for educational/portfolio purposes. The symptom checker
provides general guidance only and is **not** a substitute for professional
medical advice.
